# 弗洛洛启动动画（独立插件）

与弗洛洛主题分离。即使动画或视频加载失败，也不会影响主题和调色板。

- 亮度 4 横版红线背景，自上而下扫描 1 秒
- 转入 `assets/splash.mp4`
- 视频过半时底部逐字字幕
- 视频 16 秒时左侧 Great Vibes `DeepSeek` LOGO
- 结束后黑场、收缩、闪点，进入工作界面
- 全程按 Enter 跳过

开关由弗洛洛调色板「启动动画」控制，写入 `localStorage['flollo-splash']`。
