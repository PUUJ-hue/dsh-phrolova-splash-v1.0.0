# 弗洛洛启动动画（独立插件）

与弗洛洛主题分离。即使动画或视频加载失败，也不会影响主题和调色板。

- 亮度 4 横版红线背景，自上而下扫描 1 秒
- 转入 `assets/splash.mp4`
- 视频过半时底部逐字字幕
- 视频 16 秒时左侧 Great Vibes `DeepSeek` LOGO
- 结束后黑场、收缩、闪点，进入工作界面
- 全程按 Enter 跳过

开关由弗洛洛调色板「启动动画」控制，写入 `localStorage['flollo-splash']`。


## 兼容性

- 插件声明适配：DeepSeek Harness **0.1.0-rc.6 ～ 0.2.2-rc.1**
- 实际验证环境：**Windows Desktop 0.2.2-rc.1**
- 适用界面：Desktop / Web GUI
- 不适用于：Headless、ACP、SDK、纯 CLI profile（本插件依赖 Web GUI 渲染或宿主路由）
- 需要 `webServer` 路由；启动层与主题完全独立，主题卸载后仍可单独工作。
- 独立插件：无需主题、启动动画或其他自定义插件即可单独安装。
